var myApp = angular.module('myApp', ['infinite-scroll',  ,'ngRoute']);

myApp.run(function($rootScope, GHRepo) {
    $rootScope.ghRepo = new GHRepo();
});

myApp.controller('DemoController', function($scope,$rootScope, GHRepo) {
  $scope.ghRepo = $rootScope.ghRepo;
});

myApp.controller('SearchController', function($scope,$rootScope,$http, GHRepo) {
  $scope.locations = ["Bangalore","Hyderabad","Mumbai"];
  $scope.categories = ["All","Home","Buy/Sale","Sports"];
  $scope.searchCategory = function() {
    var location = $scope.location;
	var category = $scope.category;
	$scope.criteria = location + " " + category;
  }
  $http.get('data/data.json').then(function(response) {
   $scope.value = response.data;
   });
  $scope.ghRepo = $rootScope.ghRepo;
});

// Reddit constructor function to encapsulate HTTP and pagination logic
myApp.factory('GHRepo', function($http) {
  var GHRepo = function() {
    this.repos = [];
    this.busy = false;
    this.page = 1
  };

  GHRepo.prototype.nextPage = function() {
    if (this.busy) return;
    this.busy = true;

    var url = "https://api.github.com/search/repositories?q=angular&page="+ this.page + "&per_page=50"
    $http.get(url).success(function(data) {
      var items = data.items;
      for (var i = 0; i < items.length; i++) {
        this.repos.push(items[i]);
      }
      this.page += 1
      this.busy = false;
    }.bind(this));
  };

  return GHRepo;
});

